#ifndef BRANCH_H
#define BRANCH_H

#include <filter.h>
#include <QList>
#include <QJsonObject>
#include <QJsonArray>
#include "maincan.h"

class Branch
{
public:
    Branch();
    const QList<Filter> &brch() const;
    void setFilter(const QList<Filter> &brch);
    void setJoin(const QList<MainCAN> &brch);

    void read(const QJsonObject &json);
    void writeFilter(QJsonObject &json) const;
    void writeJoin(QJsonObject &json) const;
private:
    QList<Filter> mBrch;
    QList<MainCAN> MC;
};


#endif // BRANCH_H
