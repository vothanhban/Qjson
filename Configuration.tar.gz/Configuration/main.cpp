#include <QCoreApplication>
#include <branchs.h>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    Branchs game;
    game.newBranch();
     // Game is played; changes are made...
 //! [0]
 //! [1]
     if (!game.saveFile())
         return 1;

    return a.exec();
}
