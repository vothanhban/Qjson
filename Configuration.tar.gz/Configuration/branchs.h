#ifndef BRANCHS_H
#define BRANCHS_H

#include "branch.h"
#include <QList>
#include <QFile>
#include <QJsonDocument>

class Branchs
{
public:
    Branchs();
    const QList<Branch> &brchs()const;

    void newBranch();
    bool saveFile() const;
    void write(QJsonObject &json) const;
private:
    Branch mBranch;
    QList<Branch> mBrchs;

};

#endif // BRANCHS_H
