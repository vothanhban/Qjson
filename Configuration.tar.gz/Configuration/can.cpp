#include "can.h"

CAN::CAN()
{
    Baudrate = 0;
}
CAN::CAN(int Baudrate): Baudrate(Baudrate)
{

}
