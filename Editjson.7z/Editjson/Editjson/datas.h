#ifndef DATAS_H
#define DATAS_H

#include "data.h"
#include <QList>
#include <QJsonObject>
#include <QJsonArray>

class datas
{
public:
    datas();

    void setType(const QString &type);
    void setNamemes(const QString &name);
    void setAfter(int after);

    void setdata(const QList<data> &dt);
    void writeData(QJsonObject &json) const;
    QList<data> mData;
private:
    QString mType;
    int mAfter;
    QString mName;
};

#endif // DATAS_H
