#ifndef MEASURE_H
#define MEASURE_H

#include <content.h>
#include <QList>
#include <datas.h>
#include <QJsonArray>
#include "generator.h"
#include "maincan.h"
#include "view.h"
class datas;
class measure : public generator, public MainCAN, public view
{
public:
    measure();
    ~measure(){}

    void newBranch();
    bool saveFile() const;

    void write(QJsonObject &json) const;
private:
    QList <generator> mMeasure;
    QList <MainCAN> mMeasureCAN;
    QList <view> mvw;
};

#endif // MEASURE_H
