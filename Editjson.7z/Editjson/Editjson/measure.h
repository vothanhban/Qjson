#ifndef MEASURE_H
#define MEASURE_H

#include <content.h>
#include <QList>
#include <datas.h>
#include <QJsonArray>
class datas;
class measure : public content
{
public:
    measure();

    void newBranch();
    bool saveFile() const;
    void write(QJsonObject &json) const;
private:
    QList <content> mCnt;
};

#endif // MEASURE_H
