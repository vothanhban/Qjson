#ifndef VIEWDT_H
#define VIEWDT_H

#include <QString>
#include <QJsonObject>

class viewdt
{
public:
    viewdt();
    viewdt(QString type,QString name,int before);
    ~viewdt(){}

    void write(QJsonObject &json)const;

private:
    QString mType;
    QString mName;
    int mBefore;
};

#endif // VIEWDT_H
