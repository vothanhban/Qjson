#ifndef MAINCAN_H
#define MAINCAN_H

#include <QList>
#include <QJsonArray>
#include <QJsonObject>
#include "can.h"
#include "datas.h"
#include "content.h"
#include "contentview.h"

class MainCAN
{
public:
    MainCAN();

    void setDt(const QList <datas> &ctdt);
    void setMainCAN(const QList <CAN> &can);

    void writeMainCAN(QJsonObject &json)const;

    QList<CAN>mMainCAN;
private:
    QList <datas> mDt1;
    QList <contentview> mview;

};

#endif // MAINCAN_H
