#include "measure.h"

measure::measure()
{

}

void measure::newBranch()
{
    mMesag.clear();

    Signals sig;
    QList<Signl>listsignal;
    listsignal.append(Signl(QStringLiteral("SIG1"),0,QStringLiteral("none")));
    listsignal.append(Signl(QStringLiteral("SIG2"),2,QStringLiteral("none")));
    sig.setSig(listsignal);
    sig.setFile("sample.dbc");
    sig.setName("New_Message_1");
    mSigs.append(sig);
    datas dt;
    QList<data>listdata;
    listdata.append(data(QStringLiteral("1"),111,222));
    dt.setdata(listdata);
    dt.setType("FILTER");
    dt.setNamemes("PF");
    dt.setAfter(1);
    mDt.append(dt);

    msgs mes;
    mes.setType("IG");
    mes.setNamemes("IG1");
    mes.setAfter(1);
    mes.setmsgs(mSigs);
    mMesag.append(mes);
    content cnt;
    cnt.setContent(mMesag);
    mCnt.append(cnt);

}
bool measure::saveFile() const
{
    QFile saveFile(("save.json"));

    if (!saveFile.open(QIODevice::WriteOnly)) {
        qWarning("Couldn't open save file.");
        return false;
    }

    QJsonObject gameObject;
    write(gameObject);
    QJsonDocument saveDoc(gameObject);
    saveFile.write(saveDoc.toJson());
    return true;
}
void measure::write(QJsonObject &json) const
{
//    json["file"] = mFile;
//    json["name"] = mName;
    QJsonArray measureArray;
    foreach (const content cnt, mCnt) {
        QJsonObject measureObject;
        cnt.writeContent(measureObject);
        measureArray.append(measureObject);
    }
    json["MEASURESETUP"] = measureArray;
}
