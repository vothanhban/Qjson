#include "measure.h"
#include <QDebug>

measure::measure()
{

}

void measure::newBranch()
{
    mMeasure.clear();

    Signals sig;
    QList<Signl>listsignal;
    listsignal.append(Signl(QStringLiteral("SIG1"),0,QStringLiteral("none")));
    listsignal.append(Signl(QStringLiteral("SIG2"),2,QStringLiteral("none")));
    sig.setSig(listsignal);
    sig.setFile("sample.dbc");
    sig.setName("New_Message_1");
    mSigs.append(sig);
    datas dt;
    QList<data>listdata;
    listdata.append(data(QStringLiteral("1"),111,222));
    dt.setdata(listdata);
    dt.setType("FILTER");
    dt.setNamemes("PF");
    dt.setAfter(1);
    mDt.append(dt);

    msgs mes;
    mes.setType("IG");
    mes.setNamemes("IG1");
    mes.setAfter(1);
    mes.setmsgs(mSigs);
    mMesag.append(mes);
    //content* cnt=static_cast<content*>(this);
    content cnt;
    cnt.setContent(mMesag);
    cnt.setDt(mDt);
    mGener.append(cnt);

    CAN can;
    QList<CANdt>listcan;
    listcan.append(CANdt("CAN1",500));
    listcan.append(CANdt("CAN2",500));
    can.setCAN(listcan);
    can.setType("CAN");
    can.setAfter(1);
    mMainCAN.append(can);


    generator gener;
    gener.setGener(mGener);
    mMeasure.append(gener);

    contentview dtview;
    QList<viewdt> listview;
    listview.append(viewdt("trace","trace",1));
    dtview.setcontentview(listview);
    mView.append(dtview);

    MainCAN mCAN;
    mCAN.setMainCAN(mMainCAN);
    mCAN.setDt(mDt);
    mMeasureCAN.append(mCAN);
    view v;
    v.setView(mView);
    mvw.append(v);

}
bool measure::saveFile() const
{
    QFile saveFile(("save.json"));

    if (!saveFile.open(QIODevice::WriteOnly)) {
        qWarning("Couldn't open save file.");
        return false;
    }

    QJsonObject gameObject;
    write(gameObject);
    QJsonDocument saveDoc(gameObject);
    saveFile.write(saveDoc.toJson());
    return true;
}
void measure::write(QJsonObject &json) const
{
//    json["file"] = mFile;
//    json["name"] = mName;
    QJsonArray measureArray;
    foreach (const generator gener, mMeasure) {
        QJsonObject measureObject;
        gener.writeGener(measureObject);
        measureArray.append(measureObject);
    }
    foreach (const MainCAN maincan, mMeasureCAN)
    {
        QJsonObject measureObject;
        maincan.writeMainCAN(measureObject);
        measureArray.append(measureObject);
    }
    foreach (const view vw, mvw)
    {
        QJsonObject viewObject;
        vw.writeView(viewObject);
        measureArray.append(viewObject);
    }
    json["MEASURESETUP"] = measureArray;
}
