#include "signals.h"

Signals::Signals()
{

}
//const QList<Signl> &Signals::sigs() const
//{
//    return mSig;
//}
void Signals::setFile(const QString &name)
{
    mFile = name;
}
void Signals::setName(const QString &name)
{
    mName = name;
}
void Signals::setSig(const QList<Signl> &sigs)
{
    mSig = sigs;
}
//void Branch::read(const QJsonObject &json)
//{
//    mBrch.clear();
//    QJsonArray brchArray = json["Branch"].toArray();
//    for (int brchIndex = 0; brchIndex < brchArray.size(); ++brchIndex) {
//        QJsonObject brchObject = brchArray[brchIndex].toObject();
//        Filter br;
//        br.read(brchObject);
//        mBrch.append(br);
//    }
//}

void Signals::writeSignals(QJsonObject &json) const
{
    json["file"] = mFile;
    json["name"] = mName;
    QJsonArray sigArray;
    foreach (const Signl sig, mSig) {
        QJsonObject sigObject;
        sig.write(sigObject);
        sigArray.append(sigObject);
    }
    json["SIGNS"] = sigArray;
}

