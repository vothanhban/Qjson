#include <QCoreApplication>
#include "msgs.h"
#include "measure.h"
#include "content.h"
#include "generator.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    //content game;
    measure game;
    game.newBranch();

    game.saveFile();

    return a.exec();
}
