#include <QCoreApplication>
#include "msgs.h"
#include "measure.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    measure game;
    game.newBranch();

     if (!game.saveFile())
         return 1;



    return a.exec();
}
