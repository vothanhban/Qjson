#include "maincan.h"

MainCAN::MainCAN()
{

}
void MainCAN::setDt(const QList <datas> &ctdt)
{
    mDt1 = ctdt;
}
void MainCAN::setMainCAN(const QList <CAN> &can)
{
    mMainCAN = can;
}
void MainCAN::writeMainCAN(QJsonObject &json) const
{
    QJsonArray maincanArray;
    foreach (const CAN main , mMainCAN)
    {
        QJsonObject maincanObject;
        main.writeCAN(maincanObject);
        maincanArray.append(maincanObject);
    }
    foreach (const datas ms, mDt1) {
        QJsonObject maincanObject;
        ms.writeData(maincanObject);
        maincanArray.append(maincanObject);
    }
    foreach (const contentview cntview, mview)
    {
        QJsonObject viewObject;
        cntview.writeContentView(viewObject);
        maincanArray.append(viewObject);
    }
    json["MAIN"] = maincanArray;
}
