#ifndef GENERATOR_H
#define GENERATOR_H

#include <content.h>
#include <QList>
#include <datas.h>
#include <QJsonArray>

class generator : public content
{
public:
    generator();
    ~generator(){}

    void setGener(const QList <content> &gener);
    void writeGener(QJsonObject &json) const;

    QList<content> mGener;
private:
    QList <content> mGener1;
};

#endif // GENERATOR_H
