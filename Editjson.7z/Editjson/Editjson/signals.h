#ifndef SIGNALS_H
#define SIGNALS_H

#include <QList>
#include <QJsonObject>
#include <QJsonArray>
#include "signl.h"
#include <QString>

class Signals
{
public:
    Signals();
    ~Signals(){}
    const QList<Signl> &sigs() const;
    void setSig(const QList<Signl> &sigs);

    void setFile(const QString &file);
    void setName(const QString &name);

    void read(const QJsonObject &json);
    void writeSignals(QJsonObject &json) const;

private:
    QList<Signl> mSig;
    QString mFile;
    QString mName;

};

#endif // SIGNALS_H
