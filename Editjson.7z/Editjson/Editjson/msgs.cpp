#include "msgs.h"
#include <QDebug>
class Signl;
msgs::msgs()
{

}
void msgs::setmsgs(const QList<Signals> &msg)
{
    mSigs1 = msg;
}

void msgs::setType(const QString &type)
{
    mType = type;
}
void msgs::setNamemes(const QString &name)
{
    mName = name;
}
void msgs::setAfter(int after)
{
    mAfter = after;
}
void msgs::writeMessage(QJsonObject &json) const
{/*
    QJsonObject playerObject;
    Signl m;
    m.write(playerObject);
    json["player"] = playerObject;*/
    json["type"] = mType;
    json["AFTER"] = mAfter;
    json["name"] = mName;
    QJsonArray branchArray;
    QJsonObject branchObject;
    foreach (const Signals brch, mSigs1) {

        brch.writeSignals(branchObject);
        branchArray.append(branchObject);

    }
    json["MSGS"] = branchArray;

}
