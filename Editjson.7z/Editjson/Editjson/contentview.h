#ifndef CONTENTVIEW_H
#define CONTENTVIEW_H

#include <QList>
#include "viewdt.h"
#include <QJsonArray>
#include <QJsonObject>

class contentview
{
public:
    contentview();
    void setcontentview(const QList <viewdt> &view);
    void writeContentView(QJsonObject &json)const;

    QList <viewdt>mcontentView;
private:
    QList <viewdt>mcontentView1;
};

#endif // CONTENTVIEW_H
