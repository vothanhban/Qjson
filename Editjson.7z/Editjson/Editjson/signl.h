#ifndef SIGNL_H
#define SIGNL_H

#include <QString>
#include <QJsonObject>

class Signl
{
public:
    Signl();
    Signl(QString name,int stb,QString wave);
    ~Signl();
    QString name()const;
    void setName(const QString &name);

    void read (const QJsonObject &json);
    void write(QJsonObject &json)const;
private:
    QString mName;
    int mStb;
    QString mWave;
};

#endif // SIGNL_H

