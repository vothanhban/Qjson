#include "viewdt.h"

viewdt::viewdt()
{

}
viewdt::viewdt(QString type, QString name, int before):mType(type),mName(name),mBefore(before)
{

}
void viewdt::write(QJsonObject &json) const
{
    json["type"] = mType;
    json["name"] = mName;
    json["BEFORE"] = mBefore;
}
