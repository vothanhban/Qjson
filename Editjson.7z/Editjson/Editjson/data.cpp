#include "data.h"

data::data()
{

}
void data::write(QJsonObject &json)const
{
    json["IdMin"] = mIdMin;
    json["IdMax"] = mIdMax;
    json["Channels"] = mChannel;
}
data::data(QString chnl, int idmin, int idmax): mChannel(chnl),mIdMin(idmin),mIdMax(idmax)
{

}
