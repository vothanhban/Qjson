#ifndef VIEW_H
#define VIEW_H

#include <QJsonObject>
#include <QString>
#include "contentview.h"
#include <QJsonArray>

class view
{
public:
    view();

    void setView(const QList<contentview> &view);

    void writeView(QJsonObject &json)const;
    QList<contentview>mView;
private:

};

#endif // VIEW_H
