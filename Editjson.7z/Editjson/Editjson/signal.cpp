#include "signl.h"
#include "ui_signal.h"

Signal::Signal(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Signal)
{
    ui->setupUi(this);
}

Signal::~Signal()
{
    delete ui;
}
