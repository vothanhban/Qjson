#ifndef MSGS_H
#define MSGS_H

#include <QFile>
#include <QJsonDocument>
#include <QList>
#include "signals.h"
#include <QString>

class msgs
{
public:
    msgs();
    ~msgs(){}

    void setType(const QString &type);
    void setNamemes(const QString &name);
    void setAfter(int after);

    const QList<Signals> &signl()const;

    void setmsgs(const QList <Signals> &msg);
    void writeMessage(QJsonObject &json) const;

    QList<Signals> mSigs;
private:
    QList<Signals> mSigs1;
    QString mType;
    int mAfter;
    QString mName;

};

#endif // MSGS_H
