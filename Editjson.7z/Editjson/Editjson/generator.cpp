#include "generator.h"

#include <QDebug>

generator::generator()
{

}
void generator::setGener(const QList <content> &gener)
{
    mGener1 = gener;
}

void generator::writeGener(QJsonObject &json) const
{
//    json["file"] = mFile;
//    json["name"] = mName;
    QJsonArray generatorArray;
    foreach (const content cnt, mGener1){
        QJsonObject generatorObject;
        cnt.writeContent(generatorObject);
        generatorArray.append(generatorObject);
    }
    json["GENERATOR"] = generatorArray;

}
