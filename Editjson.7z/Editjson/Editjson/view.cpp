#include "view.h"

view::view()
{

}
void view::setView(const QList<contentview> &view)
{
    mView = view;
}
void view::writeView(QJsonObject &json) const
{
    QJsonArray viewArray;
    foreach (const contentview view, mView)
    {
        QJsonObject viewObject;
        view.writeContentView(viewObject);
        viewArray.append(viewObject);
    }
    json["VIEW"] = viewArray;
}
