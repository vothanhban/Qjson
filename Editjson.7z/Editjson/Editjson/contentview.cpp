#include "contentview.h"

contentview::contentview()
{

}
void contentview::setcontentview(const QList<viewdt> &view)
{
    mcontentView1 = view;
}
void contentview::writeContentView(QJsonObject &json) const
{
    QJsonArray viewArray;
    foreach(const viewdt view, mcontentView1)
    {
        QJsonObject viewObject;
        view.write(viewObject);
        viewArray.append(viewObject);
    }
    json["CONTENT"] = viewArray;
}
