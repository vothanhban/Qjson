#ifndef CANDT_H
#define CANDT_H

#include <QJsonObject>
#include <QString>

class CANdt
{
public:
    CANdt();
    CANdt(QString name, int baud);
    ~CANdt(){}
    void write(QJsonObject &json)const;
private:
    QString mName;
    int mBaud;

};

#endif // CANDT_H
