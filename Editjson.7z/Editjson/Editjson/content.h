#ifndef CONTENT_H
#define CONTENT_H

#include <QList>
#include "msgs.h"
#include <QString>
#include "data.h"
#include "datas.h"
class datas;
class content : public msgs
{
public:
    content();
    ~content(){}
    void setContent(const QList <msgs> &cnt);
    void setDt(const QList <datas> &ctdt);

    void writeContent(QJsonObject &json) const;

    QList<msgs> mMesag;
    QList<datas> mDt;
private:
     QList<msgs> mMesag1;
     QList <datas> mDt1;
};

#endif // CONTENT_H
