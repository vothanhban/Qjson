#ifndef CONTENT_H
#define CONTENT_H

#include <QList>
#include "msgs.h"
#include <QString>
#include "data.h"
#include "datas.h"

class content : public msgs
{
public:
    content();

    void setContent(const QList <msgs> &cnt);
    void writeContent(QJsonObject &json) const;

    QList<msgs> mMesag;
    QList<datas> mDt;
private:
     QList<msgs> mMesag1;
};

#endif // CONTENT_H
