#ifndef DATA_H
#define DATA_H

#include <QString>
#include <QJsonObject>

class data
{
public:
    data();
    data(QString chnl,int idmin, int idmax);

    void write(QJsonObject &json)const;
private:
    int mIdMin;
    int mIdMax;
    QString mChannel;
};

#endif // DATA_H
