#include "datas.h"

datas::datas()
{

}
void datas::setType(const QString &type)
{
    mType = type;
}
void datas::setNamemes(const QString &name)
{
    mName = name;
}
void datas::setAfter(int after)
{
    mAfter = after;
}
void datas::setdata(const QList<data> &dt)
{
    mData = dt;
}
void datas::writeData(QJsonObject &json) const
{
    json["type"] = mType;
    json["AFTER"] = mAfter;
    json["name"] = mName;
    QJsonArray dataArray;
    foreach (const data dt, mData) {
        QJsonObject dataObject;
        dt.write(dataObject);
        dataArray.append(dataObject);
    }
    json["data"] = dataArray;
}

