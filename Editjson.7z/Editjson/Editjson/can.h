#ifndef CAN_H
#define CAN_H

#include <QList>
#include "candt.h"
#include <QJsonObject>
#include <QJsonArray>

class CAN
{
public:
    CAN();
    void setType(const QString &type);
    void setAfter(int after);

    void setCAN(const QList <CANdt> &can);
    void writeCAN(QJsonObject &json)const;

    QList<CANdt>mCAN;
private:
    QList<CANdt>mCAN1;
    QString mType;
    int mAfter;
};

#endif // CAN_H
