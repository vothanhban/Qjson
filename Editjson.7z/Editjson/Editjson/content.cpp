#include "content.h"

content::content()
{

}
void content::setContent(const QList <msgs> &cnt)
{
    mMesag1 = cnt;

}

void content::writeContent(QJsonObject &json) const
{
    QJsonArray contentArray;
    foreach (const msgs mes, mMesag1) {
        QJsonObject contentObject;
        mes.writeMessage(contentObject);
        contentArray.append(contentObject);
    }
    foreach (const datas ms, mDt) {
        QJsonObject contentObject;
        ms.writeData(contentObject);
        contentArray.append(contentObject);
    }

    json["CONTENT"] = contentArray;
}
