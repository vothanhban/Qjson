#include "content.h"
#include <QDebug>
class datas;
content::content()
{

}
void content::setContent(const QList <msgs> &cnt)
{
    mMesag1 = cnt;

}
void content::setDt(const QList <datas> &ctdt)
{
    mDt1 = ctdt;

}

void content::writeContent(QJsonObject &json) const
{
    QJsonArray contentArray;
    foreach (const datas ms, mDt1) {
        QJsonObject contentObject;
        ms.writeData(contentObject);
        contentArray.append(contentObject);
    }
    int coun = mDt1.count();
    qDebug()<<coun;
//    datas tr = datas() ;
//    for(int j = 0; j<coun;i++)
//    {
//        tr = mDt1.at(j);
//        qDebug() <<i;
//    }
    foreach (const msgs mes, mMesag1) {
        QJsonObject contentObject;
        mes.writeMessage(contentObject);
        contentArray.append(contentObject);
    }
    json["CONTENT"] = contentArray;
}
