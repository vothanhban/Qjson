#include "candt.h"

CANdt::CANdt()
{

}
CANdt::CANdt(QString name, int baud):mName(name),mBaud(baud)
{

}
void CANdt::write(QJsonObject &json) const
{
    json["name"] = mName;
    json["baud"] = mBaud;
}
