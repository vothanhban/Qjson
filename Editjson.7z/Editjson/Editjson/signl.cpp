#include "signl.h"

Signl::Signl()
{

}
Signl::~Signl()
{

}
Signl::Signl(QString name, int stb, QString wave):mName(name),mStb(stb),mWave(wave)
{

}

QString Signl::name()const
{
    return mName;
}
void Signl::setName(const QString &name)
{
    mName = name;
}
void Signl::write(QJsonObject &json) const
{
    json["name"] = mName;
    json["stb"] = mStb;
    json["wave"] = mWave;
}
