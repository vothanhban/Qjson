#include "can.h"

CAN::CAN()
{

}
void CAN::setCAN(const QList <CANdt> &can)
{
    mCAN1 = can;
}
void CAN::writeCAN(QJsonObject &json) const
{
    json["type"] = mType;
    json["AFTER"] = mAfter;
    QJsonArray canArray;
    foreach(const CANdt can , mCAN1)
    {
        QJsonObject canObject;
        can.write(canObject);
        canArray.append(canObject);
    }
    json["CAN"] = canArray;
}
void CAN::setType(const QString &type)
{
    mType = type;
}
void CAN::setAfter(int after)
{
    mAfter = after;
}
