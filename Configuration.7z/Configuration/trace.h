#ifndef TRACE_H
#define TRACE_H
#include <QString>
#include <QJsonObject>

class trace
{
public:
    trace();
    trace(QString name);
    void write(QJsonObject &json)const;
private:
    QString jName;
};

#endif // TRACE_H
