#ifndef MAINCAN_H
#define MAINCAN_H

#include <QString>
class MainCAN
{
public:
    MainCAN();
    MainCAN(QString name);
private:
    QString name;
};

#endif // MAINCAN_H
