#ifndef MAINCAN_H
#define MAINCAN_H

#include <QString>
#include <QJsonObject>
class MainCAN
{
public:
    MainCAN();
    MainCAN(QString name);
    void write(QJsonObject &json)const;
private:
    QString jName;
};

#endif // MAINCAN_H
