#ifndef CAN_H
#define CAN_H

class CAN
{
public:
    CAN();
    CAN(int Baudrate);

private:
    int Baudrate;
};

#endif // CAN_H
