#ifndef BREAK_H
#define BREAK_H

#include <QString>
#include <QJsonObject>

class Break
{
public:
    Break();
    Break(QString name);
    void write(QJsonObject &json)const;
private:
    QString jName;

};

#endif // BREAK_H
