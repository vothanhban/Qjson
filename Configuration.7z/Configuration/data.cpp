#include "data.h"

data::data()
{

}
data::data(QString name):jName(name)
{

}
void data::write(QJsonObject &json) const
{
    json["Name"] = jName;
}
