#ifndef BRANCH_H
#define BRANCH_H

#include <filter.h>
#include <QList>
#include <QJsonObject>
#include <QJsonArray>

class Branch
{
public:
    Branch();
    const QList<Filter> &brch() const;
    void setBrch(const QList<Filter> &brch);

    void read(const QJsonObject &json);
    void write(QJsonObject &json) const;
private:
    QList<Filter> mBrch;
};


#endif // BRANCH_H
