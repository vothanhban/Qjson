#ifndef BRANCH_H
#define BRANCH_H

#include <filter.h>
#include <QList>
#include <QJsonObject>
#include <QJsonArray>
#include "maincan.h"
#include "trace.h"
#include "break.h"
#include "data.h"
#include "logging.h"
#include "path.h"
#include "can.h"
#include "ig.h"
class Branch
{
public:
    Branch();
    const QList<Filter> &brch() const;
    void setFilter(const QList<Filter> &brch);
    void setJoin(const QList<MainCAN> &brch);
    void setTrace(const QList<trace> &brch);
    void setBreak(const QList <Break> &brch);\
    void setData(const QList <data> &brch);
    void setLogging(const QList <logging> &brch);\
    void setIG(const QList<IG> &brch);

    void read(const QJsonObject &json);
    void writeFilter(QJsonObject &json) const;
    void writeJoin(QJsonObject &json) const;
    void writeTrace(QJsonObject &json)const;
    void writeBreak(QJsonObject &json)const;
    void writeData(QJsonObject &json)const;
    void writeLogging(QJsonObject &json)const;
    void writeIG(QJsonObject &json)const;
private:
    QList<Filter> mBrch;
    QList<MainCAN> MC;
    QList<trace>tr;
    QList<Break>Brk;
    QList<data>mData;
    QList<logging>mLog;
    QList<IG>mIG;

};


#endif // BRANCH_H
