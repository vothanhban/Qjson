#include <QCoreApplication>
#include "branchs.h"
#include "input.h"
#include "minput.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    mInput newdata;
    newdata.newInput();
    newdata.saveFile();
    return a.exec();
}
