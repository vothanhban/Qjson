#ifndef DATA_H
#define DATA_H

#include <QString>
#include <QJsonObject>

class data
{
public:
    data();
    data(QString name);
    void write(QJsonObject &json)const;
private:
    QString jName;
};

#endif // DATA_H
