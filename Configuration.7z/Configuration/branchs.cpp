#include "branchs.h"


Branchs::Branchs()
{
}
//const QList<Branch> &Branchs::brchs()const
//{
//    return mBrchs;
//}

void Branchs::setBranchs(const QList <Branch> &brch)
{
    mBrchs1 = brch;
}
void Branchs::writeBranchs(QJsonObject &json) const
{
//    QJsonObject playerObject;
//    Filter m;
//    m.write(playerObject);
//    json["player"] = playerObject;
    QJsonObject branchObject;
    foreach (const Branch brch, mBrchs1) {
        brch.writeFilter(branchObject);
        brch.writeJoin(branchObject);
        brch.writeTrace(branchObject);
        json["Branch"] = branchObject;
    }
    QJsonObject branchObject1;
    foreach (const Branch brch, mBrchs1) {
        brch.writeBreak(branchObject1);
        //brch.writeJoin(branchObject1);
        brch.writeData(branchObject1);
       // brch.writeTrace(branchObject1);
        json["Branch1"] = branchObject1;
    }
    QJsonObject branchObject2;
    foreach (const Branch brch, mBrchs1) {
        brch.writeLogging(branchObject2);
        //brch.writeJoin(branchObject1);
       // brch.writeData(branchObject1);
        json["Branch2"] = branchObject2;
    }
}
