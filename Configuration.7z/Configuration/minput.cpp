#include "minput.h"

mInput::mInput()
{

}

void mInput::newInput()
{
    mIp.clear();

    Branch filter;
    QList<Filter>listfilter;
    listfilter.append(Filter(QStringLiteral("PF"),1010,17));
    filter.setFilter(listfilter);
    mBrchs.append(filter);

    Branch join;
    QList<MainCAN>listjoin;
    listjoin.append(MainCAN());
    join.setJoin(listjoin);
    mBrchs.append(join);

    Branch tr;
    QList <trace>listtrace;
    listtrace.append(trace("Trace"));
    tr.setTrace(listtrace);
    mBrchs.append(tr);
    Branch brk;
    QList <Break>listbreak;
    listbreak.append(Break());
    brk.setBreak(listbreak);
    mBrchs.append(brk);
    Branch dt;
    QList <data>listdata;
    listdata.append(data("Data"));
    dt.setData(listdata);
    mBrchs.append(dt);
    Branch log;
    QList <logging>listlog;
    listlog.append(logging("Logging" , "D:\\Projects\\CANSim\\log.blf"));
    log.setLogging(listlog);
    mBrchs.append(log);
    Branchs iput;
    iput.setBranchs(mBrchs);
    mBrchss.append(iput);
    input ipjoin;
    QList <MainCAN>listipjoin;
    listipjoin.append(MainCAN());
    ipjoin.setJoin(listipjoin);
    mIp.append(ipjoin);
//    input ipcan;
//    QList <CAN>listipcan;
//    listipcan.append(CAN(500));
//    ipcan.set
    input ipig;
    QList <IG>listipig;
    listipig.append(IG("IG"));
    ipig.setIG(listipig);
    mIp.append(ipig);
    input ipFilter;
    QList <Filter>listFilter;
    listFilter.append(Filter("PF",0x7FF,0x00));
    ipFilter.setFilter(listFilter);
    mIp.append(ipFilter);
    input mip;
    mip.setInput(mBrchss);
    mIp.append(mip);
}
bool mInput::saveFile() const
{
    QFile saveFile(("save.json"));

    if (!saveFile.open(QIODevice::WriteOnly)) {
        qWarning("Couldn't open save file.");
        return false;
    }
    QJsonObject gameObject;
    write(gameObject);
    QJsonDocument saveDoc(gameObject);
    saveFile.write(saveDoc.toJson());
    return true;
}
void mInput::write(QJsonObject &json) const
{
    json["CANused"] = 2;
    QJsonObject branchsObject1;
    CAN baudrate(500);
    baudrate.write(branchsObject1);
    json["CAN1"] = branchsObject1;
    json["CAN2"] = branchsObject1;
    QJsonObject branchsObject;   
    foreach (const input brch, mIp) {
        brch.writeJoin(branchsObject);
        brch.writeInput(branchsObject);
        json["Input"] = branchsObject;
    }

//    branchsObject1.insert("CANused",2);

    QJsonObject MainObject;
    foreach (const input brch, mIp) {
        brch.writeJoin(MainObject);
        json["Main"] = MainObject;
    }
    QJsonObject IGObject;
    foreach (const input brch, mIp) {
        brch.writeJoin(IGObject);
        brch.writeFilter(IGObject);
        brch.writeIG(IGObject);
        json["Generate"] = IGObject;
    }
}
