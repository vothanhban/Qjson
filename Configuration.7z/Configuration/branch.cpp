#include "branch.h"

Branch::Branch()
{
}
const QList<Filter> &Branch::brch() const
{
    return mBrch;
}
void Branch::setBrch(const QList<Filter> &brch)
{
    mBrch = brch;
}
void Branch::read(const QJsonObject &json)
{
    mBrch.clear();
    QJsonArray brchArray = json["Branch"].toArray();
    for (int brchIndex = 0; brchIndex < brchArray.size(); ++brchIndex) {
        QJsonObject brchObject = brchArray[brchIndex].toObject();
        Filter br;
        br.read(brchObject);
        mBrch.append(br);
    }
}

void Branch::write(QJsonObject &json) const
{
    QJsonArray brchArray;
    foreach (const Filter br, mBrch) {
        QJsonObject brchObject;
        br.write(brchObject);
        brchArray.append(brchObject);
    }
    json["Branch"] = brchArray;
}
