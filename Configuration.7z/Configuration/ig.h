#ifndef IG_H
#define IG_H

#include <QString>
#include <QJsonObject>

class IG
{
public:
    IG();
    IG(QString name);
    void write(QJsonObject &json)const;
private:
    QString jName;
};

#endif // IG_H
