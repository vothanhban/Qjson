#ifndef INPUT_H
#define INPUT_H
#include <QJsonObject>
#include <QList>
#include "filter.h"
#include "branch.h"
#include <QJsonDocument>
#include "trace.h"
#include "maincan.h"
#include "branchs.h"
#include "break.h"
#include "data.h"

class input : public Branchs
{
public:
    input();

    void newBranchs();
    bool saveFile() const;
    void setInput(const QList <Branchs> &brch);
    void writeInput(QJsonObject &json) const;

    QList<Branchs> mBrchss;
private:
    QList<Branchs> mBrchss1;

    //QList<Branch> mBrchss;

};

#endif // INPUT_H
