#include "maincan.h"

MainCAN::MainCAN()
{
}
MainCAN::MainCAN(QString name):name(name)
{

}
