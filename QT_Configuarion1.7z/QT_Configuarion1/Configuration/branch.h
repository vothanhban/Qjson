#ifndef BRANCH_H
#define BRANCH_H

#include <filter.h>
#include <QList>
#include <QJsonObject>
#include <QJsonArray>
#include "maincan.h"
#include "trace.h"
class Branch
{
public:
    Branch();
    const QList<Filter> &brch() const;
    void setFilter(const QList<Filter> &brch);
    void setJoin(const QList<MainCAN> &brch);
    void setTrace(const QList<trace> &brch);

    void read(const QJsonObject &json);
    void writeFilter(QJsonObject &json) const;
    void writeJoin(QJsonObject &json) const;
    void writeTrace(QJsonObject &json)const;
private:
    QList<Filter> mBrch;
    QList<MainCAN> MC;
    QList<trace>tr;
};


#endif // BRANCH_H
