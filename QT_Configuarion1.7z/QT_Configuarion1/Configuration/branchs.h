#ifndef BRANCHS_H
#define BRANCHS_H

#include "branch.h"
#include <QList>
#include <QFile>
#include <QJsonDocument>
#include "trace.h"

class Branchs
{
public:
    Branchs();
    const QList<Branch> &brchs()const;

    void newBranch();
    bool saveFile() const;
    void write(QJsonObject &json) const;
private:
    Branch mBranch;
    QList<Branch> mBrchs;
   // char b;

};

#endif // BRANCHS_H
