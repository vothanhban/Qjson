#ifndef BRANCHS_H
#define BRANCHS_H

#include "branch.h"
#include <QList>
#include <QFile>
#include <QJsonDocument>
#include "trace.h"
#include "break.h"

class Branchs : public Branch
{
public:
    Branchs();
    //const QList<Branch> &brchs()const;
    void setBranchs(const QList <Branch> &brch);
    void writeBranchs(QJsonObject &json) const;
    QList<Branch> mBrchs;
private:
   QList<Branch> mBrchs1;
};

#endif // BRANCHS_H
