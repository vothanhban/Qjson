#include "can.h"

CAN::CAN()
{
    Baudrate = 0;
}
CAN::CAN(int Baudrate): Baudrate(Baudrate)
{

}
void CAN::write(QJsonObject &json) const
{
    json["Baud"] = Baudrate;
}
