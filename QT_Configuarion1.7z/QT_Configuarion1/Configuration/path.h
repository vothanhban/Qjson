#ifndef PATH_H
#define PATH_H


class path
{
public:
    path();
};

#endif // PATH_H
