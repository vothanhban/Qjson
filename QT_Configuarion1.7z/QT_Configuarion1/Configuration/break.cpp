#include "break.h"

Break::Break()
{

}
Break::Break(QString name): jName(name)
{

}
void Break::write(QJsonObject &json)const
{
    json["name"] = jName;
}
