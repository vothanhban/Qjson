#include "ig.h"

IG::IG()
{

}
IG::IG(QString name):jName(name)
{

}
void IG::write(QJsonObject &json) const
{
    json["Name"] = jName;
}
