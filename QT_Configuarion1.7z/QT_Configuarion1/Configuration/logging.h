#ifndef LOGGING_H
#define LOGGING_H

#include <QString>
#include <QJsonObject>

class logging
{
public:
    logging();
    logging(QString name, QString path);
    void write(QJsonObject &json)const;
private:
    QString jName;
    QString jPath;

};

#endif // LOGGING_H
