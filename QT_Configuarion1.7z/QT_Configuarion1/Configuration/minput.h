#ifndef MINPUT_H
#define MINPUT_H

#include "input.h"
#include <QString>
#include <QJsonObject>
#include <QJsonDocument>
#include <QList>
#include <can.h>

class mInput : public input
{
public:
    mInput();

    void newInput();
    bool saveFile() const;
   // void setmInput(const QList <input> &brch);
    void write(QJsonObject &json) const;

private:
    QList<input> mIp;
};
#endif // MINPUT_H
