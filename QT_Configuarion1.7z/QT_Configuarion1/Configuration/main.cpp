#include <QCoreApplication>
#include "branchs.h"
#include "input.h"
#include "minput.h"
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QFile>
#include <QStringList>

void Get1();
void Get();
void Remove();
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    mInput newdata;
    newdata.newInput();
    newdata.saveFile();
    Get();
    Remove();
   // Get1();
    return a.exec();
}
void Get(){
    QFile myFile("save.json");
    myFile.open(QIODevice::ReadOnly);
    QJsonDocument jsonContent;
    QJsonObject Objectjson;
    QString jsonString = QString::fromUtf8(myFile.readAll()).simplified();
    jsonContent = QJsonDocument::fromJson(jsonString.toUtf8());
    myFile.close();
    Objectjson = jsonContent.object();
    qDebug ()<<"Root is:"<<Objectjson;

    QJsonValueRef ValueGenerate = Objectjson.find("Generate").value();
    qDebug ()<<"Find Objectref:\n"<<ValueGenerate;
    QJsonObject ObjectGenerate = ValueGenerate.toObject();
    QJsonValueRef ValueIG1 = ObjectGenerate.find("IG1").value();
    qDebug ()<<"Find refig:\n"<<ValueIG1;
    QJsonValueRef ValueJoin = ObjectGenerate.find("Join").value();
    qDebug()<<"Find refjoin:\n"<<ValueJoin;

    ObjectGenerate.insert("Join1",ValueJoin);
    ObjectGenerate.insert("IG2", ValueIG1);
    Objectjson.insert("Generate",ObjectGenerate);
    myFile.open(QIODevice::WriteOnly);
    jsonContent .setObject(Objectjson);
    myFile.write(jsonContent.toJson());
    myFile.close();
}
void Remove(){
    QFile myFile("save.json");
    myFile.open(QIODevice::ReadOnly);
    QJsonDocument jsonContent;
    QJsonObject Objectjson;
    QString jsonString = QString::fromUtf8(myFile.readAll()).simplified();
    jsonContent = QJsonDocument::fromJson(jsonString.toUtf8());
    myFile.close();
    Objectjson = jsonContent.object();
    qDebug ()<<"Root is:"<<Objectjson;

    QJsonObject::iterator ValueGenerate = Objectjson.find("Generate");
    Objectjson.erase(ValueGenerate);
//    qDebug ()<<"Find Objectref:\n"<<ValueGenerate;
//    QJsonObject ObjectGenerate = ValueGenerate.toObject();
//    QJsonValueRef ValueIG1 = ObjectGenerate.find("IG1").value();
//    qDebug ()<<"Find refig:\n"<<ValueIG1;
//    QJsonValueRef ValueJoin = ObjectGenerate.find("Join").value();
//    qDebug()<<"Find refjoin:\n"<<ValueJoin;

//    ObjectGenerate.insert("Join1",ValueJoin);
//    ObjectGenerate.insert("IG2", ValueIG1);
//    Objectjson.insert("Generate",ObjectGenerate);
    myFile.open(QIODevice::WriteOnly);
    jsonContent .setObject(Objectjson);
    myFile.write(jsonContent.toJson());
    myFile.close();
}
//void Get1(){
//    QFile myFile("save.json");
//    myFile.open(QIODevice::ReadOnly);
//    QJsonDocument jsonContent;
//    QJsonObject roots;
//    QString jsonString = QString::fromUtf8(myFile.readAll()).simplified();
//    jsonContent = QJsonDocument::fromJson(jsonString.toUtf8());
//    myFile.close();
//    roots = jsonContent.object();
//    qDebug ()<<"Root is that:\n"<<roots;

//    QJsonValueRef Objectref = roots.find("Input").value();
//    qDebug ()<<"Find Objectref:\n"<<Objectref;
//    QJsonObject refinput = Objectref.toObject();
//    QJsonValueRef refbrs =refinput.find("Branches").value();
//    qDebug ()<<"Find refbrs:\n"<<refbrs;
//     QJsonObject refbranches = refbrs.toObject();
//    QJsonValueRef refbrs1 =refbranches.find("Branch").value();
//    qDebug ()<<"Find refbrs1:\n"<<refbrs1;
//    QJsonObject refbrs2 = refbrs1.toObject();
//       QJsonValueRef refbrs3 =refbrs2.find("Filter").value();
//       qDebug()<<"Filter:"<<refbrs3;
//       refbranches.insert("Filter",refbrs3);
////    QJsonValueRef refjoin = ref.find("Join").value();
////    qDebug()<<"Find refjoin:\n"<<refjoin;

////    ref.insert("Join1",refjoin);
//    refbranches.insert("Branch3", refbrs1);
//    refinput.insert("Branches",refbranches);
//    QJsonObject::iterator roots1 = roots.insert("Input",refinput);

////    QJsonObject ex = roots["Input"].toObject();
////    qDebug() << "ROOT WANTED:" <<ex;
////    roots.insert("test",5);
////    roots.insert("Player", 10);
////    roots.insert(".Input", ex);
////    roots.insert("..CAN 3", Objectref);

////    qDebug()<<"Roots after insert\n"<<roots;
////    qDebug()<<"check contains is:"<< roots.contains("..Main");
////    qDebug()<<"Check size"<<roots.size();
////    roots.remove("Player");
////    roots.remove("test");
////     qDebug()<<"Check size 1"<<roots.size();
////    QJsonObject::iterator tx = roots.find(".Input");
////    QJsonObject::iterator tt = roots.erase(tx);
////    qDebug()<<"Check end\n"<<tt.key();
////    qDebug()<<roots.size();
////    qDebug() <<"Root after remove\n"<<roots;
//    myFile.open(QIODevice::WriteOnly);
//    jsonContent .setObject(roots);
////    QJsonDocument doc(roots);
////    doc.setObject(roots);
////    myFile.write(doc.toJson());
//    myFile.write(jsonContent.toJson());
//    myFile.close();
//}
