#ifndef INPUT_H
#define INPUT_H

class Input
{
public:
    Input();
    Input();
};

#endif // INPUT_H
