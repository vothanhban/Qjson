#include "logging.h"

logging::logging()
{

}
logging::logging(QString name ,QString path):jName(name) , jPath(path)
{

}
void logging::write(QJsonObject &json) const
{
    json["Name"] = jName;
    json["Path"] = jPath;
}
