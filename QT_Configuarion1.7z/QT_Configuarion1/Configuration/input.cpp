#include "input.h"

input::input()
{

}

void input::setInput(const QList <Branchs> &brch)
{
    mBrchss1 = brch;
}
void input::writeInput(QJsonObject &json) const
{
    QJsonObject branchsObject;
    foreach (const Branchs brch, mBrchss1) {
        brch.writeBranchs(branchsObject);
        json["Branches"] = branchsObject;
    }
}

