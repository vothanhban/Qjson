#include "trace.h"

trace::trace()
{
}
trace::trace(QString name):jName(name)
{

}
void trace::write(QJsonObject &json)const
{
    json["name"] = jName;
}
