#include "path.h"

path::path()
{

}
