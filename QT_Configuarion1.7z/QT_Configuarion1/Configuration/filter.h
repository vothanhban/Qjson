#ifndef FILTER_H
#define FILTER_H

#include <QString>
#include <QJsonObject>

class Filter
{
public:
    Filter();
    Filter(QString name,int mask,int id);
    QString name() const;
    void setName(const QString &name);

    int Mask() const;
    void setMask(const int mask);

    int Id()const;
    void setId(const int id);

    void read(const QJsonObject &json);
    void write(QJsonObject &json) const;
private:
    QString mName;
    int mMask;
    int mId;
};

#endif // FILTER_H
