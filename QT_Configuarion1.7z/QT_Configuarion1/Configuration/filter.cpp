#include "filter.h"
Filter::Filter()
{
    mMask =0;
    mId = 0;
}
Filter::Filter(QString name,int mask,int id): mName(name) , mMask(mask),mId(id)
{

}
QString Filter::name() const
{
    return mName;
}
void Filter::setName(const QString &name)
{
    mName = name;
}

int Filter::Mask() const
{
    return mMask;
}
void Filter::setMask(const int mask)
{
    mMask = mask;
}
int Filter::Id()const
{
    return mId;
}
void Filter::setId(const int id)
{
    mId = id;
}

void Filter::read(const QJsonObject &json)
{

    mName = json["Name"].toString();
    mMask = json["Mask"].toInt();
    mId = json["ID"].toInt();
}
void Filter::write(QJsonObject &json) const
{

    json["Name"] = mName;
    json["Mask"] = mMask;
    json["ID"] = mId;
}
