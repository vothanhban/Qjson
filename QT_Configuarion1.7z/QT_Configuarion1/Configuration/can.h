#ifndef CAN_H
#define CAN_H

#include <QString>
#include <QJsonObject>

class CAN
{
public:
    CAN();
    CAN(int Baudrate);
    void write(QJsonObject &json)const;
private:
    int Baudrate;
};

#endif // CAN_H
