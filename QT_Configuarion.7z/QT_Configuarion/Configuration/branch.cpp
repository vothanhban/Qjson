#include "branch.h"

Branch::Branch()
{
}
const QList<Filter> &Branch::brch() const
{
    return mBrch;
}
void Branch::setFilter(const QList<Filter> &brch)
{
    mBrch = brch;
}
void Branch::setJoin(const QList<MainCAN> &brch)
{
    MC = brch;
}
//void Branch::read(const QJsonObject &json)
//{
//    mBrch.clear();
//    QJsonArray brchArray = json["Branch"].toArray();
//    for (int brchIndex = 0; brchIndex < brchArray.size(); ++brchIndex) {
//        QJsonObject brchObject = brchArray[brchIndex].toObject();
//        Filter br;
//        br.read(brchObject);
//        mBrch.append(br);
//    }
//}

void Branch::writeFilter(QJsonObject &json) const
{
    //QJsonObject brchObject;
    foreach (const Filter br, mBrch) {
        QJsonObject brchObject;
        br.write(brchObject);
       // brchArray.append(brchObject);
        json["Filter"] = brchObject;
    }
    //json["Filter"] = brchObject;
}
void Branch::writeJoin(QJsonObject &json) const
{
    //QJsonArray brchArray;
    foreach (const MainCAN mc, MC){
        QJsonObject mcObject;
        mc.write(mcObject);
       // brchArray.append(mcObject);
        json["Join"] = mcObject;
    }
    //json["Join"] = brchArray;
}
