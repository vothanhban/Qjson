#include "branchs.h"


Branchs::Branchs()
{
}
const QList<Branch> &Branchs::brchs()const
{
    return mBrchs;
}
void Branchs::newBranch()
{
    mBrchs.clear();

    Branch filter;
    QList<Filter>listfilter;
    listfilter.append(Filter(QStringLiteral("PF"),1010,17));
    filter.setFilter(listfilter);
    mBrchs.append(filter);

    Branch join;
    QList<MainCAN>listjoin;
    listjoin.append(MainCAN());
    join.setJoin(listjoin);
    mBrchs.append(join);

}
bool Branchs::saveFile() const
{
    QFile saveFile(("save.json"));


    if (!saveFile.open(QIODevice::WriteOnly)) {
        qWarning("Couldn't open save file.");
        return false;
    }

    MainCAN mc();
    QJsonObject gameObject;
    write(gameObject);
    QJsonDocument saveDoc(gameObject);
   saveFile.write(saveDoc.toJson());
    return true;
}
void Branchs::write(QJsonObject &json) const
{
//    QJsonObject playerObject;
//    Filter m;
//    m.write(playerObject);
//    json["player"] = playerObject;
     //QJsonObject branchObject;
    //char *x= (char*)malloc(10*sizeof(char));
    //char *x = "Branch";
    QJsonArray branchArray;
    foreach (const Branch brch, mBrchs) {
        QJsonObject branchObject;
        //QJsonObject branchObject1;
        brch.writeFilter(branchObject);
        json["Branch"] = branchObject;
        //brch.writeJoin(branchObject);
        //branchArray.append(branchObject);
        //brch.writeJoin();
        //branchObject.insert("ban",10);
        //json["Branch"] = branchObject;
        //json["ban"] = branchObject1;
    }
    foreach (const Branch brch1, mBrchs){
        QJsonObject branhcObject1;
        brch1.writeJoin(branhcObject1);
        json["branch1"] = branhcObject1;
    }

    //json["Branch"] = branchArray;
}
