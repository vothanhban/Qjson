#include "input.h"

Input::Input()
{

}
