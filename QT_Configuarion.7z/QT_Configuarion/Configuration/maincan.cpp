#include "maincan.h"

MainCAN::MainCAN()
{
}
MainCAN::MainCAN(QString name):jName(name)
{

}
void MainCAN::write(QJsonObject &json)const
{
    json["name"] = jName;
}
